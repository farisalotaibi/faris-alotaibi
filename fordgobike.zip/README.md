# Data Visualization for fordgobike

## data set over view

the data analyzed include information about duration for a bike ride its supported by Udacity

## What is the structure of your dataset?

There are 183412 fordgobike trips in the dataset want to analyze thim

## What is/are the main feature(s) of interest in your dataset?

there is many interest in this data but i will look into the average in the trip duration. 

## What features in the dataset do you think will help support your investigation into your feature(s) of interest?

by looking to the data i think the trip duration will help this investigate i will look to the duration by second and minutes.

## Of the features you investigated, were there any unusual distributions? Did you perform any operations on the data to tidy, adjust, or change the form of the data? If so, why did you do this?

what value i looking for it showed , there no unusual distributions

## Discuss the distribution(s) of your variable(s) of interest. Were there any unusual points? Did you need to perform any transformations?

its the trip duration took a large , i need to do a log transformation

## Talk about some of the relationships you observed in this part of the investigation. How did the feature(s) of interest vary with other features in the dataset?

i see when the age increase the trip duration decrease (inverse relationships)

## Did you observe any interesting relationships between the other features (not the main feature(s) of interest)?

I was expecting to find that the male will got the higher duration trip but the male gender become the lowest all of them and customer spending more time rather than the subscriber.

## Were there any interesting or surprising interactions between features?
the duration trip is higher for male but percentage is higher for women and other
